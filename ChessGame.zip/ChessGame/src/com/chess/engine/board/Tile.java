// Implementing logical packages - effort to better organise code
// Where I'll place my Tile class
package com.chess.engine.board;

import com.chess.engine.pieces.Piece;
import com.google.common.collect.ImmutableMap;
import java.util.*;

/**
 * 08/10/2021
 * @author Karl
 */

// Chess board consists of 64 tiles(a-h, 1-8), this class represents a single tile
public abstract class Tile {

    // Represents each tile number
    // Protected so it can only be accessed by its sub-classes & final so it's set only once when constructed
    // Basic attempt at Immutability principle implementation
    protected final int tileCoordinate;
    
    private static final Map<Integer, EmptyTile> EMPTY_TILES_CACHE = createAllPossibleEmptyTiles();
    
    private static Map<Integer, EmptyTile> createAllPossibleEmptyTiles() {
        
        final Map<Integer, EmptyTile> emptyTileMap = new HashMap<>();
        
        for(int i = 0; i < BoardUtils.NUM_TILES; i++) {
            emptyTileMap.put(i, new EmptyTile(i));
        }
        
        //Collections.unmodifiableMap(emptyTileMap); <-- Option for not using Guava, this is built into JDK
        return ImmutableMap.copyOf(emptyTileMap); // ImmutableMap is part of 3rd party library (Guava) from Joshua Bloch
    }
    
    public static Tile createTile(final int tileCoordinate, final Piece piece) {
        // If anyone wants an empty tile they get one of the cached empty tiles, otherwise they'll get a new occupied tile
        return piece != null ? new OccupiedTile(tileCoordinate, piece) : EMPTY_TILES_CACHE.get(tileCoordinate);
    }
    
    // Creates individual tiles & assigns their coordinates
    private Tile(final int tileCoordinate) {
        this.tileCoordinate = tileCoordinate;
    }
    
    // Identifies if tile is occupied or not
    public abstract boolean isTileOccupied();
    
    // Gets the piece off of a given tile
    public abstract Piece getPiece();
    
    // Gets the tile coordinate
    public int getTileCoordinate(){
        return this.tileCoordinate;
    }
    
    // Sub-class of EmptyTile to define behaviour for empty tiles
    public static final class EmptyTile extends Tile {
        
        private EmptyTile(final int coordinate) {
            super(coordinate);
        }
        
        @Override
        public String toString() { // PGN
            return "-"; // If not occupied, print out hyphen
        }
        
        @Override
        public boolean isTileOccupied() {
            return false;
        }
        
        @Override 
        public Piece getPiece() {
            return null;
        }
    }
    
    // Sub-class of OccupiedTile to define behaviour for occupied tiles
    public static final class OccupiedTile extends Tile {
        
        private final Piece pieceOnTile;
        
        private OccupiedTile(int tileCoordinate, final Piece pieceOnTile) { // Grabs tile & piece on that tile
            super(tileCoordinate);
            this.pieceOnTile = pieceOnTile;
        }
        
        @Override
        public String toString() {
            return getPiece().getPieceAlliance().isBlack() ? getPiece().toString().toLowerCase() : // Black show up as lower case, white as upper case
                   getPiece().toString(); // If occupied, print out piece
        }
        
        @Override
        public boolean isTileOccupied() {
            return true;
        }
        
        @Override
        public Piece getPiece() {
            return this.pieceOnTile;
        }
    }
    
    
}
