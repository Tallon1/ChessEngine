package com.chess.engine;

import com.chess.engine.board.BoardUtils;
import com.chess.engine.player.BlackPlayer;
import com.chess.engine.player.Player;
import com.chess.engine.player.WhitePlayer;

/**
 * 08/10/2021
 * @author Karl
 */

public enum Alliance {
    
    WHITE {
        @Override
        public int getDirection() {
            return -1; // Returns different values to differentiate
        }
        
        @Override
        public int getOppositeDirection() {
            return 1; // Returns opposite different values to differentiate during En Passant moves
        }

        @Override
        public boolean isWhite() {
            return true; // Returns true for White, yes this is a White piece
        }

        @Override
        public boolean isBlack() {
            return false;
        }

        @Override
        public Player choosePlayer(final WhitePlayer whitePlayer, 
                                   final BlackPlayer blackPlayer) {
            return whitePlayer; // White Player chooses White Player
        }
        
        @Override
        public boolean isPawnPromotionSquare(int position) {
            return BoardUtils.EIGHTH_ROW[position]; // Asks if the piece is on the 8th row/rank meaning it's eligible for promotion
        }
    },
    
    BLACK {
        @Override
        public int getDirection() {
            return 1; // Returns different values to differentiate
        }
        
        @Override
        public int getOppositeDirection() {
            return -1; // Returns opposite different values to differentiate during En Passant moves
        }

        @Override
        public boolean isWhite() {
            return false;
        }

        @Override
        public boolean isBlack() {
            return true; // Returns true for Black, yes this is a Black piece
        }

        @Override
        public Player choosePlayer(final WhitePlayer whitePlayer, 
                                   final BlackPlayer blackPlayer) {
            return blackPlayer; // Black Player chooses Black Player
        }

        @Override
        public boolean isPawnPromotionSquare(int position) {
            return BoardUtils.FIRST_ROW[position]; // Asks if the piece is on the 1st row/rank meaning it's eligible for promotion
        }
    };
    
    public abstract int getDirection();
    public abstract int getOppositeDirection();
    public abstract boolean isWhite();
    public abstract boolean isBlack();
    public abstract boolean isPawnPromotionSquare(int position);    
    public abstract Player choosePlayer(WhitePlayer whitePlayer, BlackPlayer blackPlayer);
}