package com.chess.engine.pieces;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.MajorAttackMove;
import com.chess.engine.board.Move.MajorMove;
import com.chess.engine.board.Tile;
import com.google.common.collect.ImmutableList;
import java.util.*;

/**
 * 08/10/2021
 * @author Karl
 */
public class King extends Piece {

    // Possible offset moves for the King, rules dictated by the horizontal counting of tiles (not always the same for each direction)
    private final static int[] CANDIDATE_MOVE_COORDINATE = { -9, -8, -7, -1, 1, 7, 8, 9 }; // Like a combo of the Rook & Bishop movesets
    
    public King(final Alliance pieceAlliance, 
                final int piecePosition) {
        super(PieceType.KING, piecePosition, pieceAlliance, true);
    }
    
    public King(final Alliance pieceAlliance,
                final int piecePosition,
                final boolean isFirstMove){
        super(PieceType.KING, piecePosition, pieceAlliance, isFirstMove);
    }
    
    @Override
    public Collection<Move> calculateLegalMoves(final Board board) {

        final List<Move> legalMoves = new ArrayList<>(); // Captures possible legal moves
                
        // Loops through each move e.g. check if 6 from current position is valid through loop, then checks 10 & so on
        for(final int currentCandidateOffset : CANDIDATE_MOVE_COORDINATE) {
            final int candidateDestinationCoordinate = this.piecePosition + currentCandidateOffset;
            // Applies offsets to current position
            if(BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate)) {
                final Tile candidateDestinationTile = board.getTile(candidateDestinationCoordinate); //Check if it's a valid tile coordinate
                // If exclusion doesn't apply, continue through the loop
                if(isFirstColumnExclusion(this.piecePosition, currentCandidateOffset) ||
                   isEighthColumnExclusion(this.piecePosition, currentCandidateOffset)) {
                    continue;
                }
                if(!candidateDestinationTile.isTileOccupied()){ // If tile is NOT occupied
                    legalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
                } else { // If it IS occupied
                    final Piece pieceAtDestination = candidateDestinationTile.getPiece();
                    final Alliance pieceAlliance = pieceAtDestination.getPieceAlliance();
                    if(this.pieceAlliance != pieceAlliance) { // Checks if piece on reachable tile is an enemy piece or not
                        legalMoves.add(new MajorAttackMove(board, this, candidateDestinationCoordinate, pieceAtDestination)); // Adds attacking moves to legalMoves list
                    }
                }
            }
        }
        return ImmutableList.copyOf(legalMoves);
    }
    
    @Override
    public King movePiece(Move move) { // Essentially places new King in target tile
        return new King(move.getMovedPiece().getPieceAlliance(), move.getDestinationCoordinate());
    }
    
    //ASCII Assignment Process
    @Override
    public String toString() {
        return PieceType.KING.toString();
    }
    
    // Following code is covering the exceptions to the above rule, covers column exclusions for King
    private static boolean isFirstColumnExclusion(final int currentPosition, final int candidateOffset){
        return BoardUtils.FIRST_COLUMN[currentPosition] && (candidateOffset == -9 || candidateOffset == -1 ||
                candidateOffset == 7);
    }
    
    private static boolean isEighthColumnExclusion(final int currentPosition, final int candidateOffset){
        return BoardUtils.EIGHTH_COLUMN[currentPosition] && (candidateOffset == -7 || candidateOffset == 1 ||
                candidateOffset == 9);
    }
}
