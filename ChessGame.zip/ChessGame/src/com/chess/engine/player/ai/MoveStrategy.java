package com.chess.engine.player.ai;

import com.chess.engine.board.Board;
import com.chess.engine.board.Move;

/**
 * 22/11/2021
 * @author Karl
 */
public interface MoveStrategy {
        
    Move execute(Board board);
    
}
