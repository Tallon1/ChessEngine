package com.chess.engine.player.ai;

import com.chess.engine.board.Board;
import com.chess.engine.pieces.Piece;
import com.chess.engine.player.Player;

/**
 * 22/11/2021
 * @author Karl
 */
public final class StandardBoardEvaluator implements BoardEvaluator {
        
    private static final int CHECK_BONUS = 50; // Equals half a pawn value if current board ends in check
    private static final int CHECK_MATE_BONUS = 10000; // Huge number as it's the highest value move
    private static final int DEPTH_BONUS = 100;
    private static final int CASTLE_BONUS = 60; // 60% of a pawn's value
    
    @Override
    public int evaluate(final Board board,
                        final int depth) {
        return scorePlayer(board, board.whitePlayer(), depth) - // If White has an advantage, return a positive number
               scorePlayer(board, board.blackPlayer(), depth);  // If Black has an advantage, return a negative number
    }
    
    private int scorePlayer(final Board board,
                                   final Player player,
                                   final int depth) {
        return pieceValue(player) + 
               mobility(player) + 
               check(player) +
               checkmate(player, depth) + 
               castled(player);
    }
    
    private static int castled(final Player player) {
        return player.isCastled() ? CASTLE_BONUS : 0;
    } // If castled, provide BONUS : otherwise return 0
    
    private static int checkmate(Player player, int depth) {
        return player.getOpponent().isInCheck() ? CHECK_MATE_BONUS * depthBonus(depth) : 0; // If checkmate is possible, provide BONUS : otherwise return 0
    } // If Check mate is possible before reaching depth, provide even larger bonus
    
    private static int depthBonus(final int depth) {
        return depth == 0 ? 1 : DEPTH_BONUS * depth;
    }
    
    private static int check(final Player player) {
        return player.getOpponent().isInCheck() ? CHECK_BONUS : 0; // If the player is in check, return isInCheck : otherwise return 0
    }
    
    private static int mobility(final Player player) { 
        return player.getLegalMoves().size(); // Mobility represents for the current board, how many legal moves does the player have
    }
    
    private static int pieceValue(final Player player) {
        int pieceValueScore = 0;
        for(final Piece piece : player.getActivePieces()) {
            pieceValueScore += piece.getPieceValue();
        }
        return pieceValueScore;
    }    
}