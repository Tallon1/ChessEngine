package com.chess.engine.player.ai;

import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.engine.player.MoveTransition;

/**
 * 22/11/2021
 * @author Karl
 */
public class MiniMax implements MoveStrategy { // The AI will involve this MiniMax method to calculate the best move at a given time
// Min / Max will be assigned to each colour to represent their winning position on the board in terms of values
    private final BoardEvaluator boardEvaluator;
    private final int searchDepth;
    
    public MiniMax(final int searchDepth) {
        this.boardEvaluator = new StandardBoardEvaluator();
        this.searchDepth = searchDepth;
    }
    
    public String toString() {
        return "MiniMax";
    }
    
    @Override
    public Move execute(Board board) {
        final long startTime = System.currentTimeMillis(); // Captures the current moment in milliseconds
        
        Move bestMove = null;
        
        int highestSeenValue = Integer.MIN_VALUE;
        int lowestSeenValue = Integer.MAX_VALUE;
        int currentValue;
        
        System.out.println(board.currentPlayer() + " thinking with depth = " + this.searchDepth); // Depending on current player's colour, call MIN or MAX method
        
        final int numMoves = board.currentPlayer().getLegalMoves().size();
        
        for (final Move move : board.currentPlayer().getLegalMoves()) {
            final MoveTransition moveTransition = board.currentPlayer().makeMove(move); // Make the current player's move
            if (moveTransition.getMoveStatus().isDone()) { // When the player's move is completed
                currentValue = board.currentPlayer().getAlliance().isWhite() ? // After move is made, if current player is white
                                min(moveTransition.getTransitionBoard(), this.searchDepth - 1) : // Next move is a MINIMISING move i.e A Black Move
                                max(moveTransition.getTransitionBoard(), this.searchDepth - 1); // Next move is a MAXIMISING move i.e. A White Move
                if (board.currentPlayer().getAlliance().isWhite() && // If White & highestSeenValue is less than currentValue
                    currentValue >= highestSeenValue) {
                        highestSeenValue = currentValue; // Set currentValue to that highestSeenValue
                        bestMove = move; // Then set the "Best Move" to be that seen move
                } else if (board.currentPlayer().getAlliance().isBlack() && // If Black & lowestSeenValue is great than currentValue
                           currentValue <= lowestSeenValue) {
                    lowestSeenValue = currentValue; // Set currentValue to lowestSeenValue
                    bestMove = move; // Then set the "Best Move" to that lowestSeenValue
                }
            } 
        }
        
        final long executionTime = System.currentTimeMillis() - startTime; // Output recorded time
        
        return bestMove;
    }
    
    private int min(final Board board, // Recursive method to continously discover lowest possible value
                    final int depth) {
        if(depth == 0 || isEndGameScenario(board)) { // i.e. Game Over, determines when to stop the recursive process
            return this.boardEvaluator.evaluate(board, depth);
        }                           //MAX_VALUE
        int lowestSeenValue = Integer.MAX_VALUE; // Give variable the HIGHEST possible value at first (Large positive number)
        for (final Move move : board.currentPlayer().getLegalMoves()) { // Then go through players legal moves
            final MoveTransition moveTransition = board.currentPlayer().makeMove(move); // Make those possible moves
            if (moveTransition.getMoveStatus().isDone()) {
                final int currentValue = max(moveTransition.getTransitionBoard(), depth - 1); // Record the result of those moves
                if (currentValue <= lowestSeenValue) { // Check current value against the lowest seen value, less than or equal to
                    lowestSeenValue = currentValue; // Set that lowest seen value as the current value
                }
            }
        }
        return lowestSeenValue;
    }
    
    private static boolean isEndGameScenario(final Board board) {
        return board.currentPlayer().isInCheckMate() ||
               board.currentPlayer().isInStaleMate();
    }
    
    private int max(final Board board, // Recursive method to continously discover highest possible value
                    final int depth) {
        if(depth == 0 || isEndGameScenario(board)) { // Continue searching the game tree, unless it is an end game scenario or depth is bottomed out
            return this.boardEvaluator.evaluate(board, depth);
        }                            //MIN_VALUE
        int highestSeenValue = Integer.MIN_VALUE; // Give variable the LOWEST possible value at first (Large negative number)
        for (final Move move : board.currentPlayer().getLegalMoves()) { // Then go through players legal moves
            final MoveTransition moveTransition = board.currentPlayer().makeMove(move); // Make those possible moves
            if (moveTransition.getMoveStatus().isDone()) {
                final int currentValue = min(moveTransition.getTransitionBoard(), depth - 1); // Record the result of those moves
                if (currentValue >= highestSeenValue) { // Check current value against the highest seen value, great than or equal to
                    highestSeenValue = currentValue; // Set that highest seen value as the current value
                }
            }
        }
        return highestSeenValue;
    }
}