package com.chess.engine.player.ai;

import com.chess.engine.board.Board;

/**
 * 22/11/2021
 * @author Karl
 */
public interface BoardEvaluator {
    
    int evaluate(Board board, int depth); // Board evaluator returning corresponding values (i.e in favour of White/Black, white = positive / black = negative)
    
}
