package com.chess.engine.player;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.KingSideCastleMove;
import com.chess.engine.board.Move.QueenSideCastleMove;
import com.chess.engine.board.Tile;
import com.chess.engine.pieces.Piece;
import com.chess.engine.pieces.Rook;
import com.google.common.collect.ImmutableList;
import java.util.*;

/**
 * 11/10/2021
 * @author Karl
 */
public class BlackPlayer extends Player {
    
    public BlackPlayer(final Board board, 
                       final Collection<Move> whiteStandardLegalMoves, 
                       final Collection<Move> blackStandardLegalMoves) {
        super(board, blackStandardLegalMoves, whiteStandardLegalMoves); // Super order is important for each colour
    }

    @Override
    public Collection<Piece> getActivePieces() {
        return this.board.getBlackPieces();
    }
    
    @Override
    public Alliance getAlliance() {
        return Alliance.BLACK;
    }
    
    public Player getOpponent() {
        return this.board.whitePlayer();
    }

    @Override // Castling process handler
    protected Collection<Move> calculateKingCastles(final Collection<Move> playerLegals,
                                                    final Collection<Move> opponentsLegals) {
        final List<Move> kingCastles = new ArrayList<>();
        
        // Black's King-Side Castling
        if(this.playerKing.isFirstMove() && !this.isInCheck()) { // If it's the King's first move & isn't in check
            if(!this.board.getTile(5).isTileOccupied() && 
               !this.board.getTile(6).isTileOccupied()) { // If #5 & #6 are not occupied
                final Tile rookTile = this.board.getTile(7); // #7 is the tile h1 Rook should be on
                if(rookTile.isTileOccupied() && rookTile.getPiece().isFirstMove()) { // If Rook is present & it's Rook's first move
                    if(Player.calculateAttacksOnTile(5, opponentsLegals).isEmpty() && // Checks squares inbetween destination & current
                       Player.calculateAttacksOnTile(6, opponentsLegals).isEmpty() &&
                       rookTile.getPiece().getPieceType().isRook()) { // Checks if attackable, Cannot move into a check position
                           kingCastles.add(new KingSideCastleMove(this.board,
                                                                  this.playerKing, 
                                                                  6, 
                                                                  (Rook)rookTile.getPiece(), 
                                                                  rookTile.getTileCoordinate(), 
                                                                  5)); // Add to legal moves
                    }
                }
            }
            
            // Black's Queen-Side Castling
            if(!this.board.getTile(1).isTileOccupied() &&
               !this.board.getTile(2).isTileOccupied() &&
               !this.board.getTile(3).isTileOccupied()) { // If #1-#3 aren't occupied
                final Tile rookTile = this.board.getTile(0); // #0 is the tile a1 Rook should be on
                if(rookTile.isTileOccupied() && rookTile.getPiece().isFirstMove() &&
                   Player.calculateAttacksOnTile(2, opponentsLegals).isEmpty() &&
                   Player.calculateAttacksOnTile(3, opponentsLegals).isEmpty() &&
                   rookTile.getPiece().getPieceType().isRook()) { // If Rook is present & it's Rook's first move
                    kingCastles.add(new QueenSideCastleMove(this.board,
                                                            this.playerKing, 
                                                            2, 
                                                            (Rook)rookTile.getPiece(), 
                                                            rookTile.getTileCoordinate(), 
                                                            3)); // Add to legal moves
                }
            }
        }
        return ImmutableList.copyOf(kingCastles);
    }
    
}
