package com.chess.engine.player;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.engine.board.Move.KingSideCastleMove;
import com.chess.engine.board.Move.QueenSideCastleMove;
import com.chess.engine.board.Tile;
import com.chess.engine.pieces.Piece;
import com.chess.engine.pieces.Rook;
import com.google.common.collect.ImmutableList;
import java.util.*;

/**
 * 11/10/2021
 * @author Karl
 */
public class WhitePlayer extends Player {

    public WhitePlayer(final Board board, 
                       final Collection<Move> whiteStandardLegalMoves, 
                       final Collection<Move> blackStandardLegalMoves) {
        super(board, whiteStandardLegalMoves, blackStandardLegalMoves); // Super order is important for each colour
    }
    
    @Override
    public Collection<Piece> getActivePieces() {
        return this.board.getWhitePieces();
    }
    
    @Override
    public Alliance getAlliance() {
        return Alliance.WHITE;
    }

    @Override
    public Player getOpponent() {
        return this.board.blackPlayer();
    }

    @Override // Castling process handler
    protected Collection<Move> calculateKingCastles(final Collection<Move> playerLegals,
                                                    final Collection<Move> opponentsLegals) {
        final List<Move> kingCastles = new ArrayList<>();
        
        // White's King-Side Castling
        if(this.playerKing.isFirstMove() && !this.isInCheck()) { // If it's the King's first move & isn't in check
            if(!this.board.getTile(61).isTileOccupied() && 
               !this.board.getTile(62).isTileOccupied()) { // If #61 & #62 are not occupied
                final Tile rookTile = this.board.getTile(63); // #63 is the tile h1 Rook should be on
                if(rookTile.isTileOccupied() && rookTile.getPiece().isFirstMove()) { // If Rook is present & it's Rook's first move
                    if(Player.calculateAttacksOnTile(61, opponentsLegals).isEmpty() && // Checks squares inbetween destination & current
                       Player.calculateAttacksOnTile(62, opponentsLegals).isEmpty() &&
                       rookTile.getPiece().getPieceType().isRook()) { // Checks if attackable, Cannot move into a check position
                           kingCastles.add(new KingSideCastleMove(this.board,
                                                                  this.playerKing, 
                                                                  62, 
                                                                  (Rook)rookTile.getPiece(), 
                                                                  rookTile.getTileCoordinate(), 
                                                                  61)); // Add to legal moves
                    }
                }
            }
            
            // White's Queen-Side Castling
            if(!this.board.getTile(59).isTileOccupied() &&
               !this.board.getTile(58).isTileOccupied() &&
               !this.board.getTile(57).isTileOccupied()) { // If #57-#59 aren't occupied
                final Tile rookTile = this.board.getTile(56); // #56 is the tile a1 Rook should be on
                if(rookTile.isTileOccupied() && rookTile.getPiece().isFirstMove() &&
                   Player.calculateAttacksOnTile(58, opponentsLegals).isEmpty() &&
                   Player.calculateAttacksOnTile(59, opponentsLegals).isEmpty() &&
                   rookTile.getPiece().getPieceType().isRook()) { // If Rook is present & it's Rook's first move
                    kingCastles.add(new QueenSideCastleMove(this.board,
                                                            this.playerKing, 
                                                            58, 
                                                            (Rook)rookTile.getPiece(), 
                                                            rookTile.getTileCoordinate(), 
                                                            59)); // Add to legal moves
                }
            }
        }
        return ImmutableList.copyOf(kingCastles);
    }
}
