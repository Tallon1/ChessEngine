package com.chess.gui;

import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.player.MoveTransition;
import com.chess.engine.board.Tile;
import com.chess.engine.pieces.Piece;
import com.chess.engine.player.ai.MiniMax;
import com.chess.engine.player.ai.MoveStrategy;
import com.google.common.collect.Lists;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ExecutionException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

/**
 * 11/10/2021
 *
 * @author Karl
 */
public class Table extends Observable {

    private final JFrame gameFrame;
    private final GameHistoryPanel gameHistoryPanel;
    private final TakenPiecesPanel takenPiecesPanel;
    private final BoardPanel boardPanel;
    private final MoveLog moveLog;
    private final GameSetup gameSetup;
    
    private Board chessBoard;

    private Tile sourceTile;
    private Tile destinationTile;
    private Piece humanMovedPiece;
    private BoardDirection boardDirection;
    
    private Move computerMove;

    private boolean highlightLegalMoves;

    private static final Dimension OUTER_FRAME_DIMENSION = new Dimension(730, 600);
    private static final Dimension BOARD_PANEL_DIMENSION = new Dimension(400, 350);
    private static final Dimension TILE_PANEL_DIMENSION = new Dimension(10, 10);

    private static final String defaultPieceImagesPath = "src/art/simple/";
    //private static final String defaultHighlightLegalMovePath = "src/art/misc/green_dot.png";

    private final Color lightTileColor = Color.decode("#eeeed2");
    private final Color darkTileColor = Color.decode("#769656");
    
    private static final Table INSTANCE = new Table();

    private Table() {
        this.gameFrame = new JFrame("Chess is cool again");
        this.gameFrame.setLayout(new BorderLayout());
        final JMenuBar tableMenuBar = createTableMenuBar();
        this.gameFrame.setJMenuBar(tableMenuBar);
        this.gameFrame.setSize(OUTER_FRAME_DIMENSION);
        this.chessBoard = Board.createStandardBoard();
        this.gameHistoryPanel = new GameHistoryPanel();
        this.takenPiecesPanel = new TakenPiecesPanel();
        this.boardPanel = new BoardPanel();
        this.moveLog = new MoveLog();
        this.addObserver(new TableGameAIWatcher());
        this.gameSetup = new GameSetup(this.gameFrame, true);
        this.boardDirection = BoardDirection.NORMAL;
        this.highlightLegalMoves = false;
        this.gameFrame.add(this.takenPiecesPanel, BorderLayout.WEST);
        this.gameFrame.add(this.boardPanel, BorderLayout.CENTER);
        this.gameFrame.add(this.gameHistoryPanel, BorderLayout.EAST);
        this.gameFrame.setVisible(true);
    }
    
    public static Table get() {
        return INSTANCE;
    }
    
    public void show() {
        Table.get().getMoveLog().clear();
        Table.get().getGameHistoryPanel().redo(chessBoard, Table.get().getMoveLog());
        Table.get().getTakenPiecesPanel().redo(Table.get().getMoveLog());
        Table.get().getBoardPanel().drawBoard(Table.get().getGameBoard());
    }
    
    private GameSetup getGameSetup() {
        return this.gameSetup;
    }
    
    private Board getGameBoard() {
        return this.chessBoard;
    }
    
    public JMenuBar createTableMenuBar() {
        final JMenuBar tableMenuBar = new JMenuBar();
        tableMenuBar.add(createFileMenu());
        tableMenuBar.add(createPreferencesMenu());
        tableMenuBar.add(createOptionsMenu());
        return tableMenuBar;
    }

    private JMenu createFileMenu() {
        final JMenu fileMenu = new JMenu("File");
        final JMenuItem openPGN = new JMenuItem("Load PGN File");
        openPGN.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Open up that PGN file boi!");
            }
        });
        fileMenu.add(openPGN);

        final JMenuItem exitMenuItem = new JMenuItem("Exit"); // Exit function
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fileMenu.add(exitMenuItem);

        return fileMenu;
    }

    private JMenu createPreferencesMenu() { // Basic preferences menu for direction, etc

        final JMenu preferencesMenu = new JMenu("Preferences");
        final JMenuItem flipBoardMenuItem = new JMenuItem("Flip Board");
        flipBoardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                boardDirection = boardDirection.opposite();
                boardPanel.drawBoard(chessBoard); // When envoked, drawBoard plus traverse method to reserve the drawing of the board
            }
        });
        preferencesMenu.add(flipBoardMenuItem); // Adds option to menu
        preferencesMenu.addSeparator();

        final JCheckBoxMenuItem legalMoveHighlighterCheckbox = new JCheckBoxMenuItem("Highlight Legal Moves", false); // Defaults to false

        legalMoveHighlighterCheckbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                highlightLegalMoves = legalMoveHighlighterCheckbox.isSelected();
            }
        });

        preferencesMenu.add(legalMoveHighlighterCheckbox); // Adds checkbox to menu
        return preferencesMenu;
    }
    
    private JMenu createOptionsMenu() {
        
        final JMenu optionsMenu = new JMenu("Options");
        
        final JMenuItem setupGameMenuItem = new JMenuItem("Setup Game");
        setupGameMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Table.get().getGameSetup().promptUser();
                Table.get().setupUpdate(Table.get().getGameSetup());
            }
        }) ;
        
        optionsMenu.add(setupGameMenuItem);
        
        return optionsMenu;
    }
    
    // Implementing an "Observer Pattern" for the AI agent
    private void setupUpdate(final GameSetup gameSetup) { // When human player is done it's move, notify AI agent to make it's move
        setChanged(); // Identifies something has changed
        notifyObservers(gameSetup); // Notify observer to update
    }
    
    private static class TableGameAIWatcher implements Observer {

        @Override
        public void update(final Observable o, // When human player finishes move, make the AI move
                           final Object arg) {

            if (Table.get().getGameSetup().isAIPlayer(Table.get().getGameBoard().currentPlayer()) &&
                !Table.get().getGameBoard().currentPlayer().isInCheckMate() &&
                !Table.get().getGameBoard().currentPlayer().isInStaleMate()) {
                System.out.println(Table.get().getGameBoard().currentPlayer() + " is set to AI, thinking..."); // Identifies AI's turn
                final AIThinkTank thinkTank = new AIThinkTank();
                thinkTank.execute();
            }
            
            if (Table.get().getGameBoard().currentPlayer().isInCheckMate()) { // Checkmate handler for AI win
                System.out.println("Game Over: Player " + Table.get().getGameBoard().currentPlayer() + " is in checkmate!" + "Game Over");
            }

            if (Table.get().getGameBoard().currentPlayer().isInStaleMate()) { // Stalemate handler for AI win
                System.out.println("Game Over: Player " + Table.get().getGameBoard().currentPlayer() + " is in stalemate!" + "Game Over");
            }
        }
    }
    
    private void updateGameBoard(final Board board) {
        this.chessBoard = board;
    }

    private void updateComputerMove(final Move move) {
        this.computerMove = move;
    }
    
    private MoveLog getMoveLog() {
        return this.moveLog;
    }
    
    private GameHistoryPanel getGameHistoryPanel() {
        return this.gameHistoryPanel;
    }
    
    private TakenPiecesPanel getTakenPiecesPanel() {
        return this.takenPiecesPanel;
    }
    
    private BoardPanel getBoardPanel() {
        return this.boardPanel;
    }
    
    private void moveMadeUpdate(final PlayerType playerType) {
        setChanged();
        notifyObservers(playerType);
    }
    
    private static class AIThinkTank extends SwingWorker<Move, String> {
        private AIThinkTank() {
        }
        
        @Override // Operates in background for calculating best moves in conjuction with MiniMax methods
        protected Move doInBackground() {
            final MoveStrategy miniMax = new MiniMax(4);
            final Move bestMove = miniMax.execute(Table.get().getGameBoard());           
            return bestMove;
        }
        
        @Override
        public void done() { // Once AI agent makes a move, update the board accordingly
            try {
                final Move bestMove = get();
                Table.get().updateComputerMove(bestMove);
                Table.get().updateGameBoard(Table.get().getGameBoard().currentPlayer().makeMove(bestMove).getTransitionBoard());
                Table.get().getMoveLog().addMove(bestMove);
                Table.get().getGameHistoryPanel().redo(Table.get().getGameBoard(), Table.get().getMoveLog());
                Table.get().getTakenPiecesPanel().redo(Table.get().getMoveLog());
                Table.get().getBoardPanel().drawBoard(Table.get().getGameBoard());
                Table.get().moveMadeUpdate(PlayerType.COMPUTER);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
    }
 
    public enum BoardDirection {
        NORMAL { // Normal returns Flipped
            @Override
            List<TilePanel> traverse(final List<TilePanel> boardTiles) {
                return boardTiles;
            }

            @Override
            BoardDirection opposite() {
                return FLIPPED;
            }
        },
        FLIPPED { // Flipped returns Normal
            @Override
            List<TilePanel> traverse(final List<TilePanel> boardTiles) {
                return Lists.reverse(boardTiles); // Guava resource to "traverse" lists backwards, essentially flipping them
            }

            @Override
            BoardDirection opposite() {
                return NORMAL;
            }
        };

        abstract List<TilePanel> traverse(final List<TilePanel> boardTiles);

        abstract BoardDirection opposite();

    }

    private class BoardPanel extends JPanel { // Represents the entire Board

        final List<TilePanel> boardTiles;

        BoardPanel() { // Process for keeping track of each tile & adding them to our JPanel
            super(new GridLayout(8, 8)); // Essentially adds 64 tiles to this list
            this.boardTiles = new ArrayList<>();
            for (int i = 0; i < BoardUtils.NUM_TILES; i++) {
                final TilePanel tilePanel = new TilePanel(this, i);
                this.boardTiles.add(tilePanel);
                add(tilePanel);
            }
            setPreferredSize(BOARD_PANEL_DIMENSION);
            validate();
        }

        public void drawBoard(final Board board) {
            removeAll(); // Remove all components on the board
            for (final TilePanel tilePanel : boardDirection.traverse(boardTiles)) { // Envoke drawBoard + traverse method to reserve the drawing of the board
                tilePanel.drawTile(board); // Draw each tile panel
                add(tilePanel); // Add each tile panel to the board
            }
            validate();
            repaint();
        }
    }

    public static class MoveLog { // Method to record moves made

        private final List<Move> moves;

        MoveLog() {
            this.moves = new ArrayList<>();
        }

        public List<Move> getMoves() {
            return this.moves;
        }

        public void addMove(final Move move) {
            this.moves.add(move);
        }

        public int size() {
            return this.moves.size(); // Returns number of elements in log
        }

        public void clear() {
            this.moves.clear();
        }

        public Move removeMove(final int index) {
            return this.moves.remove(index);
        }

        public boolean removeMove(final Move move) {
            return this.moves.remove(move);
        }
    }
    
    enum PlayerType {
        HUMAN,
        COMPUTER
    }

    private class TilePanel extends JPanel { // Represents Tiles, will place a tile in each of the 8x8s

        private final int tileId;

        TilePanel(final BoardPanel boardPanel,
                final int tileId) {
            super(new GridBagLayout());
            this.tileId = tileId;
            setPreferredSize(TILE_PANEL_DIMENSION);
            assignTileColor();
            assignTilePieceIcon(chessBoard);

            addMouseListener(new MouseListener() { // Handler for clicks & selecting moves
                @Override
                public void mouseClicked(final MouseEvent e) { // Left click selects - Right click cancels in-motion selection
                    if (SwingUtilities.isRightMouseButton(e)) { // Is the event a right mouse click, will be a "cancel" button if misclicked
                        sourceTile = null;
                        destinationTile = null;
                        humanMovedPiece = null;
                    } else if (SwingUtilities.isLeftMouseButton(e)) { // For making actual selections
                        if (sourceTile == null) { // Did you make a sourceTile selection yet?
                            sourceTile = chessBoard.getTile(tileId); // Get the source tile you clicked on
                            humanMovedPiece = sourceTile.getPiece(); // If not tile isn't empty, let the player grab it's piece from the tile
                            if (humanMovedPiece == null) { // If tile IS empty
                                sourceTile = null; // Set sourceTile to null again & exits code
                            }
                        } else {
                            destinationTile = chessBoard.getTile(tileId);
                            final Move move = Move.MoveFactory.createMove(chessBoard, sourceTile.getTileCoordinate(), destinationTile.getTileCoordinate());
                            final MoveTransition transition = chessBoard.currentPlayer().makeMove(move);
                            if (transition.getMoveStatus().isDone()) {
                                chessBoard = transition.getTransitionBoard();
                                moveLog.addMove(move);
                            }
                            sourceTile = null;
                            destinationTile = null;
                            humanMovedPiece = null;
                        }
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                gameHistoryPanel.redo(chessBoard, moveLog);
                                takenPiecesPanel.redo(moveLog);
                                if(gameSetup.isAIPlayer(chessBoard.currentPlayer())) {
                                    Table.get().moveMadeUpdate(PlayerType.HUMAN);
                                }
                                boardPanel.drawBoard(chessBoard);
                            }
                        });
                    }
                }

                @Override
                public void mouseExited(final MouseEvent e) {
                }

                @Override
                public void mouseEntered(final MouseEvent e) {
                }

                @Override
                public void mouseReleased(final MouseEvent e) {
                }

                @Override
                public void mousePressed(final MouseEvent e) {
                }
            });
            validate();
        }

        public void drawTile(final Board board) {
            assignTileColor();
            assignTilePieceIcon(board);
            validate();
            repaint();
        }
        
        private void highlightLegals(final Board board) {
            if (highlightLegalMoves) {
                for (final Move move : pieceLegalMoves(board)) {
                    if (move.getDestinationCoordinate() == this.tileId) { // If this tile is a tile this piece can move to, add the following img
                        try {
                            add(new JLabel(new ImageIcon(ImageIO.read(new File("src/art/misc/green_dot"))))); // Add special label
                        }
                        catch (final IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        private Collection<Move> pieceLegalMoves(final Board board) {
            if (humanMovedPiece != null && humanMovedPiece.getPieceAlliance() == board.currentPlayer().getAlliance()) {
                return humanMovedPiece.calculateLegalMoves(board);
            }
            return Collections.emptyList();
        }

        private void assignTilePieceIcon(final Board board) {
            this.removeAll();
            if (board.getTile(this.tileId).isTileOccupied()) { // If there's pieces on the board we pass in, print those pieces onto the board
                try {
                    final BufferedImage image
                            = // Essentially says get the piece & colour from the art directory
                            ImageIO.read(new File(defaultPieceImagesPath + board.getTile(this.tileId).getPiece().getPieceAlliance().toString().substring(0, 1)
                                    + board.getTile(this.tileId).getPiece().toString() + ".png")); // Constructs path to art directory
                    add(new JLabel(new ImageIcon(image)));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void assignTileColor() { // Assigns tiles their individual colours based on Odds & Evens
            if (BoardUtils.EIGHTH_ROW[this.tileId]
                    || BoardUtils.SIXTH_ROW[this.tileId]
                    || BoardUtils.FOURTH_ROW[this.tileId]
                    || BoardUtils.SECOND_ROW[this.tileId]) {
                setBackground(this.tileId % 2 == 0 ? lightTileColor : darkTileColor); // If on 1st, 3rd, 5th or 7th row AND even, make it a light colour
            } else if (BoardUtils.SEVENTH_ROW[this.tileId]
                    || BoardUtils.FIFTH_ROW[this.tileId]
                    || BoardUtils.THIRD_ROW[this.tileId]
                    || BoardUtils.FIRST_ROW[this.tileId]) {
                setBackground(this.tileId % 2 != 0 ? lightTileColor : darkTileColor); // Algorithm flips for opposite effect
            }
        }
    }
}
